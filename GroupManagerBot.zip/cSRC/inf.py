from web3 import Web3
class env:
    API_KEY = "5828713462:AAFO9egyb_wDGcpiyznY90eGyTzVUC1Zxlk"
    INVITE_LINK = ''
    GROUP_CHAT_ID = ''
    ETH_NODE_URL = ''
    USDC_CONTRACT_ADDRESS = Web3.to_checksum_address('0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA')
    WALLET_ADDRESS = '0xe3fBb0520850098Ce7E5cfA09F28fe3EffBb9A58'
    ADMIN_PASSWORD = '6e3c69f-11ee'