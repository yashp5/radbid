import sqlite3
import pandas as pd
import os
import uuid

def export_sqlite_to_excel(table_name):
    conn = sqlite3.connect(dbUser.db_route)
    query = f"SELECT * FROM {table_name}"
    df = pd.read_sql_query(query, conn)
    unique_filename = str(uuid.uuid4()) + '.xlsx'
    output_dir = './media'
    os.makedirs(output_dir, exist_ok=True)
    excel_file_path = os.path.join(output_dir, unique_filename)
    df.to_excel(excel_file_path, index=False)
    conn.close()
    return excel_file_path



class dbUser:
    db_route = 'db.sqlite3'
    db_group_chat_id = int()
    def __init__(self, id: int, user_name=None, date_joined=None, is_human=False, captcha=None, referral_points=0, refered_by=None,chat_id=None) -> None:
        self.id = id
        self.user_name = user_name
        self.date_joined = date_joined
        self.is_human = is_human
        self.captcha = captcha
        self.referral_points = referral_points
        self.refered_by = refered_by
        self.chat_id = chat_id

    def create(self):
        conn = sqlite3.connect(dbUser.db_route)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (id,user_name,date_joined,is_human,captcha,referral_points,refered_by,chat_id)
            VALUES (?,?,?,?,?,?,?,?)
        ''',
                       (self.id, self.user_name, self.date_joined, self.is_human,
                        self.captcha, self.referral_points, self.refered_by,self.chat_id)
                       )
        conn.commit()
        conn.close()

    @staticmethod
    def get_user_by_id(id: int):
        conn = sqlite3.connect(dbUser.db_route)
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM users WHERE id=?', (id,))
        result = cursor.fetchone()

        if result:
            (id, user_name, date_joined, is_human,
             captcha, referral_points, refered_by ,chat_id) = result

            user = dbUser(
                id=id, user_name=user_name, date_joined=date_joined, is_human=is_human, captcha=captcha, referral_points=referral_points, refered_by=refered_by ,chat_id=chat_id
            )
            conn.close()
            return user

        conn.close()
        return None
    
    def save(self):
        conn = sqlite3.connect(dbUser.db_route)
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE users SET
            user_name=?, date_joined=?, is_human=?,captcha=?, referral_points=?, refered_by=?, chat_id=?
            WHERE id=? 
        ''', 
        (self.user_name, self.date_joined, self.is_human,
                        self.captcha, self.referral_points, self.refered_by  ,self.chat_id , self.id)
        )

        conn.commit()
        conn.close()

    def delete(self):
        conn = sqlite3.connect(dbUser.db_route)
        cursor = conn.cursor()

        cursor.execute('DELETE FROM users WHERE id=?', (self.id,))

        conn.commit()
        conn.close()

class Admins:
    db_route = 'db.sqlite3'
    db_group_chat_id = int()
    def __init__(self, id: int)-> None:
        self.id = id
    def create(self):
        conn = sqlite3.connect(Admins.db_route)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO admins (id)
            VALUES (?)
        ''',
                       (self.id,)
                       )
        conn.commit()
        conn.close()
    @staticmethod
    def is_admin(id: int):
        conn = sqlite3.connect(Admins.db_route)
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM admins WHERE id=?', (id,))
        result = cursor.fetchone()

        if result:
            (id) = result
            conn.close()
            return True
        conn.close()
        return False
  
    def delete(self):
        conn = sqlite3.connect(Admins.db_route)
        cursor = conn.cursor()

        cursor.execute('DELETE FROM admins WHERE id=?', (self.id,))

        conn.commit()
        conn.close()

class AdditionalData:
    db_route = 'db.sqlite3'
    def __init__(self, id: int,chat_id:int,welcome_text:str,group_name:str,last_block=None)-> None:
        self.id = id
        self.chat_id = chat_id
        self.welcome_text = welcome_text
        self.group_name = group_name
        self.last_block = last_block
    def create(self):
        conn = sqlite3.connect(AdditionalData.db_route)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO datas (id,chat_id,welcome_text,group_name,last_block)
            VALUES (?,?,?,?,?)
        ''',
                       (self.id,self.chat_id,self.welcome_text,self.group_name,self.last_block)
                       )
        conn.commit()
        conn.close()
    @staticmethod
    def get_group_by_id(id: int):
        conn = sqlite3.connect(AdditionalData.db_route)
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM datas WHERE id=?', (id,))
        result = cursor.fetchone()

        if result:
            (id,chat_id,welcome_text,group_name,last_block) = result
            group_data = AdditionalData(id=id,chat_id=chat_id,welcome_text=welcome_text,group_name=group_name,last_block=last_block)
            conn.close()
            return group_data
        conn.close()
        return None
    
    def save(self):
        conn = sqlite3.connect(AdditionalData.db_route)
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE datas SET
            chat_id=?, welcome_text=?, group_name=?, last_block=?
            WHERE id=? 
        ''', 
        (self.chat_id , self.welcome_text,self.group_name,self.last_block,self.id)
        )

        conn.commit()
        conn.close()
  
    def delete(self):
        conn = sqlite3.connect(AdditionalData.db_route)
        cursor = conn.cursor()

        cursor.execute('DELETE FROM datas WHERE id=?', (self.id,))

        conn.commit()
        conn.close()










