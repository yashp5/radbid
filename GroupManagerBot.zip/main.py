from contextvars import Context
import logging

from telegram import __version__ as TG_VER

try:
    from telegram import __version_info__
except ImportError:
    __version_info__ = (0, 0, 0, 0, 0)  # type: ignore[assignment]

if __version_info__ < (20, 0, 0, "alpha", 1):
    raise RuntimeError(
        f"This example is not compatible with your current PTB version {TG_VER}. To view the "
        f"{TG_VER} version of this example, "
        f"visit https://docs.python-telegram-bot.org/en/v{TG_VER}/examples.html"
    )
from telegram import *
from telegram.ext import *

from cSRC.inf import env as ENV
from cSRC.dbUser import dbUser as USER
from cSRC.dbUser import Admins as ADMINS
from cSRC.dbUser import AdditionalData as ADATA
from cSRC.dbUser import export_sqlite_to_excel
from cSRC.TokenHandler import TokenHandler , text_transaction_details
from datetime import datetime,timedelta
import random
from captcha.image import ImageCaptcha
HTML = 'HTML'
WALLET_UPDATE = 'WALLET_UPDATE'
# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
# set higher logging level for httpx to avoid all GET and POST requests being logged
logging.getLogger("httpx").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)

# Define a few command handlers. These usually take the two arguments update and
# context.
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if update.message.chat.type == 'private':
        remove_job_if_exists(WALLET_UPDATE,context)
        context.job_queue.run_repeating(check_if_tx,timedelta(seconds=10),name=WALLET_UPDATE)
        referrable = False
        if not USER.get_user_by_id(user.id) :
            newUser = USER(user.id,user.username,str(datetime.now()),False,random.randint(100,999),0,None)
            newUser.create()
            referrable = True
        elif USER.get_user_by_id(user.id).is_human == False or USER.get_user_by_id(user.id).refered_by == None : 
            referrable = True
        if referrable:
            refferer_id = update.message.text.split()[1] if len(update.message.text.split())>1  else None
            if refferer_id:
                if USER.get_user_by_id(int(refferer_id)):
                    refferer = USER.get_user_by_id(int(refferer_id))
                    refferer.referral_points+=1
                    refferer.save()
                    getUser = USER.get_user_by_id(user.id)
                    getUser.refered_by = refferer_id
                    getUser.save()
                else:
                    await update.message.reply_text('Wrong referral link')        
        
        user_data = USER.get_user_by_id(user.id)
        if user_data:
            if not user_data.is_human:
                image = ImageCaptcha(fonts=['font/LGB.ttf'])
                await update.message.reply_photo(image.generate(user_data.captcha),caption='''Please send the captcha text''',parse_mode=HTML)

async def db(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message.chat.type == 'private':
        user = update.effective_user
        if ADMINS.is_admin(user.id):
            await update.message.reply_document(open(export_sqlite_to_excel('users'),'rb'))
    

async def check_if_tx(context:ContextTypes.DEFAULT_TYPE) -> None:
    datas = TokenHandler()
    print(datas)
    if len(datas)>0:
        group_data = ADATA.get_group_by_id(1)
        if int(datas[-1]['blockNumber']) == int(group_data.last_block):
            return
        group_data.last_block = int(datas[-1]['blockNumber'])
        group_data.save()

        for data in datas:
            if data['blockNumber'] > group_data.last_block:
                await context.bot.send_message(ADATA.get_group_by_id(1).chat_id,text_transaction_details(data),parse_mode=HTML)
    
async def user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:   
    for new_member in update.message.new_chat_members:
        user = new_member
        await update.message.reply_html(
            rf"""
Hi {user.mention_html()}!
{ADATA.get_group_by_id(1).welcome_text}
            """,
            reply_markup=ForceReply(selective=True),
        )
        if not USER.get_user_by_id(user.id):
            newUser = USER(user.id,user.username,str(datetime.now()),False,random.randint(100,999),0,update.message.chat_id)
            newUser.create()
        user_data = USER.get_user_by_id(user.id)
        user_data.chat_id = update.message.chat_id
        user_data.save()
        if not user_data.is_human:
            reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton(text='Verify',url=f'https://t.me/{context.bot.username}?start=')]])
            await update.message.reply_text(f'{user.mention_html()} First Verify that you are a human',parse_mode=HTML,reply_markup=reply_markup)
            await context.bot.ban_chat_member(update.message.chat_id,user.id)

def remove_job_if_exists(name: str, context: ContextTypes.DEFAULT_TYPE) -> bool:
    current_jobs = context.job_queue.get_jobs_by_name(name)
    if not current_jobs:
        return False
    for job in current_jobs:
        job.schedule_removal()
    return True

async def login(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:   
    if update.message.chat.type =='private':
        user = update.effective_user
        if update.message.text.split()[1] == ENV.ADMIN_PASSWORD:  
            if not ADMINS.is_admin(user.id):
                new_entry = ADMINS(user.id)
                new_entry.create()
            reply_markup = ReplyKeyboardMarkup([['DataBase']],resize_keyboard=True)
            await update.message.reply_text('logged in as an admin',reply_markup=reply_markup)
        else :
            await update.message.reply_text('Wrong password please try again')

async def change_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:  
    if update.message.chat.type == 'private':
        user = update.effective_user
        if ADMINS.is_admin(user.id):
            new_welcome_text = update.message.text.replace('/change_text','')
            get_group = ADATA.get_group_by_id(1)
            get_group.welcome_text = new_welcome_text
            get_group.save()
            await update.message.reply_text('Successfully changed the text')
        else:
            await update.message.reply_text("Please login first")

async def sync_group(update:Update,context:ContextTypes.DEFAULT_TYPE)->None:
    user = update.effective_user
    if not update.message.chat.type == 'private':

        if ADMINS.is_admin(user.id):
            grp = ADATA.get_group_by_id(1)
            grp.chat_id = update.message.chat_id
            grp.save()
            await update.message.reply_text("Successfully synced the group")
   
async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if update.message.chat.type == 'private':
        user_data = USER.get_user_by_id(user.id)
        if user_data:
            if not user_data.is_human:
                print(f'{update.message.text} {user_data.captcha}')
                if update.message.text.replace(' ','')==str(user_data.captcha):
                    user_data.is_human = True
                    user_data.save()
                    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton('Join',url=ENV.INVITE_LINK)]])
                    await update.message.reply_text(f'Tap to join the group and invite others using your referral link \n<code>https://t.me/{context.bot.username}?start={user.id}</code>',parse_mode=HTML,reply_markup=reply_markup)
                    if user_data.chat_id:
                        await context.bot.unban_chat_member(user_data.chat_id,user_data.id)

                        
                else:  
                    user_data.captcha = str(random.randint(100,999))
                    user_data.save()
                    image = ImageCaptcha(fonts=['font/LGB.ttf'])
                    await update.message.reply_photo(image.generate(user_data.captcha),caption='''Wrong Answer please try again''',parse_mode=HTML)
async def get_bot_info(API_KEY):
    bot_app_instance = Application.builder().token(API_KEY).build()
    data = await bot_app_instance.bot.get_me()
    return data                
def main() -> None:
    application = Application.builder().token(ENV.API_KEY).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS,user_handler))
    application.add_handler(CommandHandler("login",login))
    application.add_handler(CommandHandler("sync_group",sync_group))
    application.add_handler(CommandHandler("change_text",change_text))
    application.add_handler(CommandHandler("db",db))
    application.add_handler(MessageHandler(filters.Regex(r'DataBase'),db))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))

    # Run the bot until the user presses Ctrl-C
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
