# from cSRC.dbUser import dbUser as USER
# # new_user = USER(1233222,'dfsfds','sfdf',False,'dffdf',0,None,None)
# # new_user.create()
# # print(USER.get_user_by_id(1233222).chat_id)
# # user = USER.get_user_by_id(1233222)
# # user.chat_id = 451212
# # user.save()
# user = USER.get_user_by_id(1710195890)
# user.delete()




import asyncio
from telegram import *
from telegram.ext import *
from cSRC.inf import env as ENV
async def get_bot_info(API_KEY):
    bot_app_instance = Application.builder().token(API_KEY).build()
    data = await bot_app_instance.bot.get_me()
    return data 
print(asyncio.run(get_bot_info(API_KEY=ENV.API_KEY)) )